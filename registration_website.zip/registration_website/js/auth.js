  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyCYvfBK6z6Zo4K5EDyypeFU3YvdFGKweA4",
    authDomain: "krishworks-register.firebaseapp.com",
    databaseURL: "https://krishworks-register.firebaseio.com",
    projectId: "krishworks-register",
    storageBucket: "krishworks-register.appspot.com",
    messagingSenderId: "1016660790131",
    appId: "1:1016660790131:web:b94e9b52e24bea227a1306",
    measurementId: "G-RNYCHZ1XF2"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);